export class Register {
    // ID:number
    firstname: string;
    middlename: string;
    lastname:string;
    Email: string;
    mobile: string;
    Password: string;
    confirmPassword: string;
}