export class Users {
     ID:number
    Name: string;
    Email: string;
    Password:string;
    Class: string;
    Year: string;
    City: string;
    Country: string;
}