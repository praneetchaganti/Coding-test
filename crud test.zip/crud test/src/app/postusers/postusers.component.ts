import { Component, OnInit } from '@angular/core';
import { CrudserviceService } from '../services/crudservice.service';

import { Users } from '../model/users';
import { Router } from '@angular/router';
import { UserdetailsComponent } from '../userdetails/userdetails.component'
@Component({
  providers: [UserdetailsComponent],
  selector: 'app-postusers',
  templateUrl: './postusers.component.html',
  styleUrls: ['./postusers.component.css']
})
export class PostusersComponent implements OnInit {

  Users: Users
  constructor(private service: CrudserviceService, private router: Router, private user: UserdetailsComponent) {
    this.Users = new Users()
  }

  ngOnInit() {
  }


  postUsers() {

    this.service.postUsers(this.Users).subscribe((data) => {
    })

    this.router.navigate(['userdetails'])
    this.user.ngOnInit();
  }




}
