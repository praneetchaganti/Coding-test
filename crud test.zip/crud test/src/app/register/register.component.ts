import { Component, OnInit } from '@angular/core';
import { Register } from '../model/register';
import { CrudserviceService } from '../services/crudservice.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  Users: Register

  constructor(private service: CrudserviceService) {
    this.Users = new Register();
  }


  submit() {


    if ((this.Users.firstname == null) || (this.Users.Email == null) || (this.Users.mobile == '') || (this.Users.Password == '') || (this.Users.confirmPassword == null)) {
      alert("Invalid Data")
    }
    else {
      alert(JSON.stringify(this.Users))
      this.service.submit(this.Users).subscribe((data) => {
        console.log(data)
        
      })
      this.ngOnInit();
    }

  }

  ngOnInit() {
  }

}
